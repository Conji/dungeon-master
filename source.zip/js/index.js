'use strict';

const keys = {
    NONE: 0,
    WEAPON: 1,
    ITEM: 2,
    EVENT: 3
}
var roomCount = 0;
var rooms = [];
var app = new Vue({
    el: '#app',
    data: {
        roomCount: 0,
        roomsTotal: 0,
        message: '',
        dungeon: null
    },
    methods: {
        generateNew: generateNew
    }
});

function Dungeon(rooms) {
    this.rooms = rooms;
}

function Room(id, isLocked, key, unlocks) {
    this.id = id;
    this.isLocked = isLocked;
    this.key = key || keys.NONE;
    this.unlocks = unlocks;
}


function generateNew() {
    app.message = 'Generating content...';
    rooms = [
        new Room(-1, false)
    ];
    app.roomCount = roomCount = (Math.floor(Math.random() * 50));
    app.roomsTotal = 1;
    for (var i = 0; i < roomCount - 1; ++i) {
        var isLocked = Math.floor(Math.random() * 100) > 40;
        var room = new Room(i, isLocked, keys.ITEM);
        rooms.push(room);
        app.roomsTotal = rooms.length;
    }
    app.message = 'Generation complete';
    app.dungeon = new Dungeon(rooms);
}

generateNew();